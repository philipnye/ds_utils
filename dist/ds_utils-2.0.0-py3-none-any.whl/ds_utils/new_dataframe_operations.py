# !/usr/bin/env python
# -*- coding: utf-8 -*-

from typing import Optional

import pandas as pd


def skip_rowscolumns_after(
    df: pd.DataFrame,
    skip_rows_after: Optional[int] = None,
    skip_columns_after: Optional[int] = None,
) -> pd.DataFrame:
    """
    Skip rows and columns after a certain row and column

    Parameters
        - df: DataFrame to be modified
        - skip_rows_after: Row after which rows are to be skipped
        - skip_columns_after: Column after which columns are to be skipped

    Returns
        - df: Modified DataFrame

    Notes
        - If statement handles both the case where skip_*_after is
        None and where it is 0
    """

    df = df.iloc[
        :int(
            skip_rows_after + 1 if skip_rows_after
            else len(df.index)
        ),
        :int(
            skip_columns_after + 1 if skip_columns_after
            else len(df.columns)
        )
    ]

    return df
